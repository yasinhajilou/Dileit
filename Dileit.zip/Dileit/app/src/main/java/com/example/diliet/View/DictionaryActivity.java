package com.example.diliet.View;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.EditText;

import com.example.diliet.R;

public class DictionaryActivity extends AppCompatActivity {

    EditText edtInputWord;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dictionary);
        edtInputWord = findViewById(R.id.edtWordInput);
        recyclerView = findViewById(R.id.rcyDictionary);

        edtInputWord.requestFocus();
    }
}
