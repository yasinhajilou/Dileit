package com.example.diliet.View;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.diliet.R;

public class MainActivity extends AppCompatActivity {

    Button btnReviewLeit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnReviewLeit = findViewById(R.id.btnReviewLie);

        btnReviewLeit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this , WordActivity.class);
                startActivity(intent);
            }
        });
    }
}
