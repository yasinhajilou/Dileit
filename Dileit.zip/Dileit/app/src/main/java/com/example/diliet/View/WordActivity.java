package com.example.diliet.View;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.example.diliet.R;

public class WordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_word);
    }
}
