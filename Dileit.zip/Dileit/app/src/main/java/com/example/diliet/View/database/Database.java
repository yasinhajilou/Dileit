package com.example.diliet.View.database;

public class Database {
}
